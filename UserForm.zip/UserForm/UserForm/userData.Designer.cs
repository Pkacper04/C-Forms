﻿
namespace UserForm
{
    partial class userData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNameFinal = new System.Windows.Forms.Label();
            this.lastNameFinal = new System.Windows.Forms.Label();
            this.adresFinal = new System.Windows.Forms.Label();
            this.UserPictureFinal = new System.Windows.Forms.PictureBox();
            this.phoneNumberFinal = new System.Windows.Forms.Label();
            this.BirthDateFinal = new System.Windows.Forms.Label();
            this.postCodeFinal = new System.Windows.Forms.Label();
            this.ReturnButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.UserPictureFinal)).BeginInit();
            this.SuspendLayout();
            // 
            // firstNameFinal
            // 
            this.firstNameFinal.AutoSize = true;
            this.firstNameFinal.Location = new System.Drawing.Point(321, 61);
            this.firstNameFinal.Name = "firstNameFinal";
            this.firstNameFinal.Size = new System.Drawing.Size(35, 13);
            this.firstNameFinal.TabIndex = 0;
            this.firstNameFinal.Text = "label1";
            // 
            // lastNameFinal
            // 
            this.lastNameFinal.AutoSize = true;
            this.lastNameFinal.Location = new System.Drawing.Point(321, 92);
            this.lastNameFinal.Name = "lastNameFinal";
            this.lastNameFinal.Size = new System.Drawing.Size(35, 13);
            this.lastNameFinal.TabIndex = 1;
            this.lastNameFinal.Text = "label2";
            // 
            // adresFinal
            // 
            this.adresFinal.AutoSize = true;
            this.adresFinal.Location = new System.Drawing.Point(321, 154);
            this.adresFinal.Name = "adresFinal";
            this.adresFinal.Size = new System.Drawing.Size(35, 13);
            this.adresFinal.TabIndex = 3;
            this.adresFinal.Text = "label4";
            // 
            // UserPictureFinal
            // 
            this.UserPictureFinal.Location = new System.Drawing.Point(547, 51);
            this.UserPictureFinal.Name = "UserPictureFinal";
            this.UserPictureFinal.Size = new System.Drawing.Size(150, 150);
            this.UserPictureFinal.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.UserPictureFinal.TabIndex = 5;
            this.UserPictureFinal.TabStop = false;
            // 
            // phoneNumberFinal
            // 
            this.phoneNumberFinal.AutoSize = true;
            this.phoneNumberFinal.Location = new System.Drawing.Point(321, 211);
            this.phoneNumberFinal.Name = "phoneNumberFinal";
            this.phoneNumberFinal.Size = new System.Drawing.Size(35, 13);
            this.phoneNumberFinal.TabIndex = 6;
            this.phoneNumberFinal.Text = "label6";
            // 
            // BirthDateFinal
            // 
            this.BirthDateFinal.AutoSize = true;
            this.BirthDateFinal.Location = new System.Drawing.Point(321, 121);
            this.BirthDateFinal.Name = "BirthDateFinal";
            this.BirthDateFinal.Size = new System.Drawing.Size(35, 13);
            this.BirthDateFinal.TabIndex = 2;
            this.BirthDateFinal.Text = "label3";
            // 
            // postCodeFinal
            // 
            this.postCodeFinal.AutoSize = true;
            this.postCodeFinal.Location = new System.Drawing.Point(321, 188);
            this.postCodeFinal.Name = "postCodeFinal";
            this.postCodeFinal.Size = new System.Drawing.Size(35, 13);
            this.postCodeFinal.TabIndex = 7;
            this.postCodeFinal.Text = "label6";
            // 
            // ReturnButton
            // 
            this.ReturnButton.Location = new System.Drawing.Point(300, 307);
            this.ReturnButton.Name = "ReturnButton";
            this.ReturnButton.Size = new System.Drawing.Size(75, 23);
            this.ReturnButton.TabIndex = 8;
            this.ReturnButton.Text = "Return";
            this.ReturnButton.UseVisualStyleBackColor = true;
            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
            // 
            // userData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ReturnButton);
            this.Controls.Add(this.postCodeFinal);
            this.Controls.Add(this.phoneNumberFinal);
            this.Controls.Add(this.UserPictureFinal);
            this.Controls.Add(this.adresFinal);
            this.Controls.Add(this.BirthDateFinal);
            this.Controls.Add(this.lastNameFinal);
            this.Controls.Add(this.firstNameFinal);
            this.Name = "userData";
            this.Text = "userData";
            ((System.ComponentModel.ISupportInitialize)(this.UserPictureFinal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNameFinal;
        private System.Windows.Forms.Label lastNameFinal;
        private System.Windows.Forms.Label adresFinal;
        private System.Windows.Forms.PictureBox UserPictureFinal;
        private System.Windows.Forms.Label phoneNumberFinal;
        private System.Windows.Forms.Label BirthDateFinal;
        private System.Windows.Forms.Label postCodeFinal;
        private System.Windows.Forms.Button ReturnButton;
    }
}