﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserForm
{
    public partial class userData : Form
    {
        private Form1 mainForm;

        public Form1 MainForm { get => mainForm; set => mainForm = value; }


        public userData()
        {
            InitializeComponent();
        }

        public void SetData(string firstName, string lastName, DateTime dateOfBirth, string adres, string codePost, string imageURL, string phoneNumber)
        {
            firstNameFinal.Text = firstName;
            lastNameFinal.Text = lastName;
            BirthDateFinal.Text = dateOfBirth.ToString();
            adresFinal.Text = adres;
            postCodeFinal.Text = codePost;
            UserPictureFinal.Image = Image.FromFile(imageURL);
            phoneNumberFinal.Text = phoneNumber;
            mainForm.Hide();
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            mainForm.ClearData();
            mainForm.Show();
            this.Hide();
        }
    }
}
