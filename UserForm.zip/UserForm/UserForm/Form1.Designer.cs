﻿
namespace UserForm
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.FirstNameLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.birthdayLabel = new System.Windows.Forms.Label();
            this.adresLabel = new System.Windows.Forms.Label();
            this.birthdayDatePicker = new System.Windows.Forms.DateTimePicker();
            this.postCode = new System.Windows.Forms.Label();
            this.postCodeTextBox = new System.Windows.Forms.MaskedTextBox();
            this.decorationPicture = new System.Windows.Forms.PictureBox();
            this.phoneNumberLabel = new System.Windows.Forms.Label();
            this.phoneNumberTextBox = new System.Windows.Forms.MaskedTextBox();
            this.sendDataButton = new System.Windows.Forms.Button();
            this.adresTextBox = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ImageButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.decorationPicture)).BeginInit();
            this.SuspendLayout();
            // 
            // FirstNameLabel
            // 
            this.FirstNameLabel.AutoSize = true;
            this.FirstNameLabel.Location = new System.Drawing.Point(289, 9);
            this.FirstNameLabel.Name = "FirstNameLabel";
            this.FirstNameLabel.Size = new System.Drawing.Size(52, 13);
            this.FirstNameLabel.TabIndex = 0;
            this.FirstNameLabel.Text = "Firstname";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(291, 32);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 1;
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(289, 65);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(53, 13);
            this.lastNameLabel.TabIndex = 2;
            this.lastNameLabel.Text = "Lastname";
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(291, 81);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextBox.TabIndex = 3;
            // 
            // birthdayLabel
            // 
            this.birthdayLabel.AutoSize = true;
            this.birthdayLabel.Location = new System.Drawing.Point(288, 116);
            this.birthdayLabel.Name = "birthdayLabel";
            this.birthdayLabel.Size = new System.Drawing.Size(45, 13);
            this.birthdayLabel.TabIndex = 4;
            this.birthdayLabel.Text = "Birthday";
            // 
            // adresLabel
            // 
            this.adresLabel.AutoSize = true;
            this.adresLabel.Location = new System.Drawing.Point(289, 169);
            this.adresLabel.Name = "adresLabel";
            this.adresLabel.Size = new System.Drawing.Size(33, 13);
            this.adresLabel.TabIndex = 6;
            this.adresLabel.Text = "adres";
            // 
            // birthdayDatePicker
            // 
            this.birthdayDatePicker.Location = new System.Drawing.Point(291, 132);
            this.birthdayDatePicker.Name = "birthdayDatePicker";
            this.birthdayDatePicker.Size = new System.Drawing.Size(200, 20);
            this.birthdayDatePicker.TabIndex = 7;
            // 
            // postCode
            // 
            this.postCode.AutoSize = true;
            this.postCode.Location = new System.Drawing.Point(289, 219);
            this.postCode.Name = "postCode";
            this.postCode.Size = new System.Drawing.Size(56, 13);
            this.postCode.TabIndex = 9;
            this.postCode.Text = "Post Code";
            // 
            // postCodeTextBox
            // 
            this.postCodeTextBox.Location = new System.Drawing.Point(291, 235);
            this.postCodeTextBox.Mask = "00-000";
            this.postCodeTextBox.Name = "postCodeTextBox";
            this.postCodeTextBox.Size = new System.Drawing.Size(100, 20);
            this.postCodeTextBox.TabIndex = 10;
            // 
            // decorationPicture
            // 
            this.decorationPicture.Location = new System.Drawing.Point(557, 32);
            this.decorationPicture.Name = "decorationPicture";
            this.decorationPicture.Size = new System.Drawing.Size(150, 150);
            this.decorationPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.decorationPicture.TabIndex = 11;
            this.decorationPicture.TabStop = false;
            // 
            // phoneNumberLabel
            // 
            this.phoneNumberLabel.AutoSize = true;
            this.phoneNumberLabel.Location = new System.Drawing.Point(291, 320);
            this.phoneNumberLabel.Name = "phoneNumberLabel";
            this.phoneNumberLabel.Size = new System.Drawing.Size(78, 13);
            this.phoneNumberLabel.TabIndex = 12;
            this.phoneNumberLabel.Text = "Phone Number";
            // 
            // phoneNumberTextBox
            // 
            this.phoneNumberTextBox.Location = new System.Drawing.Point(291, 337);
            this.phoneNumberTextBox.Mask = "+00 000 000 000";
            this.phoneNumberTextBox.Name = "phoneNumberTextBox";
            this.phoneNumberTextBox.Size = new System.Drawing.Size(100, 20);
            this.phoneNumberTextBox.TabIndex = 13;
            // 
            // sendDataButton
            // 
            this.sendDataButton.Location = new System.Drawing.Point(304, 386);
            this.sendDataButton.Name = "sendDataButton";
            this.sendDataButton.Size = new System.Drawing.Size(75, 23);
            this.sendDataButton.TabIndex = 14;
            this.sendDataButton.Text = "Send Data";
            this.sendDataButton.UseVisualStyleBackColor = true;
            this.sendDataButton.Click += new System.EventHandler(this.sendDataButton_Click);
            // 
            // adresTextBox
            // 
            this.adresTextBox.Location = new System.Drawing.Point(291, 185);
            this.adresTextBox.Name = "adresTextBox";
            this.adresTextBox.Size = new System.Drawing.Size(100, 20);
            this.adresTextBox.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(294, 268);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Image";
            // 
            // ImageButton
            // 
            this.ImageButton.Location = new System.Drawing.Point(291, 284);
            this.ImageButton.Name = "ImageButton";
            this.ImageButton.Size = new System.Drawing.Size(75, 23);
            this.ImageButton.TabIndex = 18;
            this.ImageButton.Text = "Set Image";
            this.ImageButton.UseVisualStyleBackColor = true;
            this.ImageButton.Click += new System.EventHandler(this.ImageButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.ImageButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.adresTextBox);
            this.Controls.Add(this.sendDataButton);
            this.Controls.Add(this.phoneNumberTextBox);
            this.Controls.Add(this.phoneNumberLabel);
            this.Controls.Add(this.decorationPicture);
            this.Controls.Add(this.postCodeTextBox);
            this.Controls.Add(this.postCode);
            this.Controls.Add(this.birthdayDatePicker);
            this.Controls.Add(this.adresLabel);
            this.Controls.Add(this.birthdayLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.lastNameLabel);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.FirstNameLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.decorationPicture)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label FirstNameLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label birthdayLabel;
        private System.Windows.Forms.Label adresLabel;
        private System.Windows.Forms.DateTimePicker birthdayDatePicker;
        private System.Windows.Forms.Label postCode;
        private System.Windows.Forms.MaskedTextBox postCodeTextBox;
        private System.Windows.Forms.PictureBox decorationPicture;
        private System.Windows.Forms.Label phoneNumberLabel;
        private System.Windows.Forms.MaskedTextBox phoneNumberTextBox;
        private System.Windows.Forms.Button sendDataButton;
        private System.Windows.Forms.MaskedTextBox adresTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button ImageButton;
    }
}

