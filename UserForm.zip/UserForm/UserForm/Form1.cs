﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserForm
{
    public partial class Form1 : Form
    {

        private int minimumFirstNameLength = 3;
        private int minimumLastNameLength = 3;
        private string imageData;
        private userData userDataForm = new userData();

        public Form1()
        {
            InitializeComponent();
        }

        private void sendDataButton_Click(object sender, EventArgs e)
        {
            if(!Walidation())
            {
                return;
            }

            userDataForm.MainForm = this;
            userDataForm.SetData(firstNameTextBox.Text,lastNameTextBox.Text,birthdayDatePicker.Value,adresTextBox.Text,postCodeTextBox.Text,imageData,phoneNumberTextBox.Text);
            userDataForm.Show();

        }

        private bool Walidation()
        {
            if (firstNameTextBox.Text.Length < minimumFirstNameLength)
                return false;
            else if (lastNameTextBox.Text.Length < minimumLastNameLength)
                return false;
            else if (adresTextBox.Text.Length == 0)
                return false;
            else if (!postCodeTextBox.MaskCompleted)
                return false;
            else if (!phoneNumberTextBox.MaskCompleted)
                return false;
            else if (imageData == null || imageData.Length == 0)
                return false;

            return true;
        }

        internal void ClearData()
        {
            firstNameTextBox.Clear();
            lastNameTextBox.Clear();
            birthdayDatePicker.ResetText();
            adresTextBox.Clear();
            postCodeTextBox.Clear();
            decorationPicture.Image = null;
            phoneNumberTextBox.Clear();
            imageData = null;

        }

        private void ImageButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openfd = new OpenFileDialog();
            openfd.Filter = "Image Files (*.jpg;*.jpeg;.*.gif;*.png)|*.jpg;*.jpeg;.*.gif;*.png";
            if(openfd.ShowDialog() == DialogResult.OK)
            {
                decorationPicture.Image = new Bitmap(openfd.FileName);
                imageData = openfd.FileName;
            }
        }
    }
}
