﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class ErrorForm : Form
    {
        private Form1 form;

        public Form1 Form { get => form; set => form = value; }

        private ErrorMessages errorType = ErrorMessages.LoginEmpty;

        public ErrorForm()
        {
            InitializeComponent(); 
        }

        public void InitErrorPanel(string message, ErrorMessages error)
        {
            errorType = error;
            form.BlockUI();
            ErrorLabel.Text = message;
            this.Show();
        }

        public void DeInitErrorPanel()
        {
            form.UnBlockUI();
            this.Hide();
            form.Focus();
            form.SetFocusOnErrorElement(errorType);
        }

        private void OkButton_Click(object sender, EventArgs e)
        {
            DeInitErrorPanel();
        }

        private void ErrorForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DeInitErrorPanel();
            this.Hide();
            form.SetNewErrorForm();
        }
    }
}
