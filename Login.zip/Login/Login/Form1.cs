﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class Form1 : Form
    {

        private const string userName = "Kerfus";
        private const string password = "123";
        ErrorForm errorForm;
        LoggedForm loggedForm;

        public Form1()
        {
            InitializeComponent();
            errorForm = new ErrorForm();
            errorForm.Form = this;

            loggedForm = new LoggedForm();
            loggedForm.Form = this;
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            if(LoginBox.Text.Length == 0)
            {
                string errorMessage = GetErrorMessage(ErrorMessages.LoginEmpty);
                errorForm.InitErrorPanel(errorMessage, ErrorMessages.LoginEmpty);
                return;
            }
            else if(PasswordBox.Text.Length == 0)
            {
                string errorMessage = GetErrorMessage(ErrorMessages.PasswordEmpty);
                errorForm.InitErrorPanel(errorMessage, ErrorMessages.PasswordEmpty);
                return;
            }

            if(!string.Equals(userName,LoginBox.Text))
            {
                string errorMessage = GetErrorMessage(ErrorMessages.LoginIncorrect);
                errorForm.InitErrorPanel(errorMessage, ErrorMessages.LoginIncorrect);
                return;
            }
            else if(!string.Equals(password, PasswordBox.Text))
            {
                string errorMessage = GetErrorMessage(ErrorMessages.PasswordIncorrect);
                errorForm.InitErrorPanel(errorMessage, ErrorMessages.PasswordIncorrect);
                return;
            }

            ClearUI();
            loggedForm.InitLoginPanel();

        }

        private void ClearUI()
        {
            LoginBox.Clear();
            PasswordBox.Clear();
        }

        public void BlockUI()
        {
            LoginBox.Enabled = false;
            PasswordBox.Enabled = false;
        }

        public void UnBlockUI()
        {
            LoginBox.Enabled = true;
            PasswordBox.Enabled = true;
        }

        public void SetNewErrorForm()
        {
            errorForm = new ErrorForm();
            errorForm.Form = this;
        }

        public void SetNewLoggedForm()
        {
            loggedForm = new LoggedForm();
            loggedForm.Form = this;
        }

        public void SetFocusOnErrorElement(ErrorMessages errorType)
        {
            if(errorType == ErrorMessages.LoginEmpty || errorType == ErrorMessages.LoginIncorrect)
            {
                LoginBox.Focus();
            }
            else if(errorType == ErrorMessages.PasswordEmpty || errorType == ErrorMessages.PasswordIncorrect)
            {
                PasswordBox.Focus();
            }
        }

        private string GetErrorMessage(ErrorMessages errorType)
        {
            switch (errorType)
            {
                case ErrorMessages.LoginEmpty:
                    return "You need to type login";
                case ErrorMessages.PasswordEmpty:
                    return "You need to type password";
                case ErrorMessages.LoginIncorrect:
                    return "Login is inncorect";
                case ErrorMessages.PasswordIncorrect:
                    return "Password is inncorect";
            }
            return "null";
        }

    }

    public enum ErrorMessages
    {
        LoginEmpty,
        PasswordEmpty,
        LoginIncorrect,
        PasswordIncorrect
    }
}
