﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class LoggedForm : Form
    {
        Form1 form;

        public Form1 Form { get => form; set => form = value; }

        public LoggedForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DeInitLoginPanel();
        }

        public void InitLoginPanel()
        {
            form.Hide();
            this.Show();
        }

        public void DeInitLoginPanel()
        {
            form.Show();
            this.Hide();
            form.Focus();
        }

        private void LoggedForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DeInitLoginPanel();
            form.SetNewLoggedForm();
        }
    }
}
